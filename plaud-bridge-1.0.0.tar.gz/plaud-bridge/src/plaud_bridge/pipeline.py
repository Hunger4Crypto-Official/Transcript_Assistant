"""
Pipeline orchestrator.

Order matters and is not arbitrary:

    ingest -> prepare -> transcribe -> diarize -> correct
           -> route -> COMPLIANCE GATE -> analyse -> persist

Routing runs BEFORE the compliance gate because the gate needs to know which
profiles matched in order to decide how strictly to treat the file. That
creates a bootstrapping problem: routing itself uses an LLM. It is solved by
routing conservatively, local-only, whenever the keyword prescore shows any
signal at all for a maximum-sensitivity profile. Better to route a business
call locally than to ship a family conversation to a third party because the
router had not classified it yet.
"""

from __future__ import annotations

import shutil
from datetime import datetime, timezone
from pathlib import Path

from .asr import transcribe
from .asr.base import ASRError
from .audio import AudioError, AudioPreparer
from .compliance import ComplianceGate, RetentionSweeper
from .config import Config
from .correct import apply_corrections
from .db import Database
from .diarize import diarize
from .logging_setup import get
from .models import (
    ProfileAnalysis, Recording, RunStats, Segment, Stage, Transcript,
)
from .profiles import extract, route
from .profiles.router import _keyword_prescore
from .storage import Vault, VaultError

log = get("pipeline")


class PipelineError(RuntimeError):
    pass


class Pipeline:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        cfg.ensure_dirs()
        self.db = Database(cfg.path("database"))
        self.vault = Vault(cfg.path("vault"))
        self.audio = AudioPreparer(cfg)
        self.gate = ComplianceGate(cfg)
        self.retention = RetentionSweeper(cfg, self.db)
        self.warn_at = float(cfg.get("cost.warn_usd_per_run", 2.0))
        self.halt_at = float(cfg.get("cost.halt_usd_per_run", 10.0))

    # =====================================================================
    # Discovery
    # =====================================================================
    def discover(self) -> list[Path]:
        inbox = self.cfg.path("inbox")
        audio_ext = {e.lower() for e in self.cfg.get("ingest.audio_extensions", [])}
        text_ext = {e.lower() for e in self.cfg.get("ingest.text_extensions", [])}
        allowed = audio_ext | text_ext
        max_mb = float(self.cfg.get("ingest.max_file_mb", 512))

        archive = inbox / "_processed"

        found: list[Path] = []
        for path in sorted(inbox.rglob("*")):
            if not path.is_file() or path.name.startswith("."):
                continue
            # Skip the archive folder. It lives under the inbox for convenience,
            # but rescanning and rehashing every previously processed file on
            # every run wastes real time once the archive gets large.
            if archive in path.parents:
                continue
            if path.suffix.lower() not in allowed:
                continue
            size_mb = path.stat().st_size / (1024 * 1024)
            if size_mb > max_mb:
                log.warning("skipping %s: %.0fMB exceeds ingest.max_file_mb (%.0f)",
                            path.name, size_mb, max_mb)
                continue
            found.append(path)
        return found

    # =====================================================================
    # Single recording
    # =====================================================================
    def process_file(self, path: Path, stats: RunStats, force: bool = False) -> Recording:
        audio_ext = {e.lower() for e in self.cfg.get("ingest.audio_extensions", [])}
        kind = "audio" if path.suffix.lower() in audio_ext else "text"

        content_hash = Vault.fingerprint(path)
        existing = self.db.hash_exists(content_hash)
        if existing and not force and self.cfg.get("ingest.dedupe", True):
            log.info("skipping %s: already processed as %s", path.name, existing)
            stats.skipped += 1
            rec = Recording(id=existing, source_name=path.name, content_hash=content_hash)
            rec.stage = Stage.COMPLETE
            return rec

        stat = path.stat()
        rec = Recording(
            source_path=str(path),
            source_name=path.name,
            content_hash=content_hash,
            size_bytes=stat.st_size,
            kind=kind,
            recorded_at=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
        )
        self.db.audit("ingest", f"{path.name} ({stat.st_size} bytes)", rec.id)
        log.info("processing %s (%s, %.1fMB)", path.name, kind, stat.st_size / 1_048_576)

        work_dir = self.cfg.path("work") / rec.id
        try:
            if kind == "audio":
                self._transcribe_audio(rec, path, work_dir)
            else:
                self._load_text(rec, path)

            if rec.transcript is None or not rec.transcript.segments:
                raise PipelineError("no transcribable content found")

            rec.stage = Stage.CORRECTED
            self._route(rec)
            self._gate(rec)

            if not rec.compliance.allow:
                self._quarantine(rec, path)
                stats.quarantined += 1
                return rec

            self._analyse(rec)
            self._persist(rec)

            rec.stage = Stage.COMPLETE
            stats.processed += 1
            stats.audio_seconds += rec.duration_seconds
            stats.cost_usd += rec.total_cost_usd

            if self.cfg.get("ingest.archive_originals", True):
                self._archive(rec, path)

        except (AudioError, ASRError, PipelineError, VaultError) as exc:
            rec.stage = Stage.FAILED
            rec.errors.append(str(exc))
            stats.failed += 1
            log.error("failed on %s: %s", path.name, exc)
            self.db.audit("failure", str(exc)[:500], rec.id)
        except Exception as exc:  # noqa: BLE001 - never lose the queue to one bad file
            rec.stage = Stage.FAILED
            rec.errors.append(f"unexpected: {exc}")
            stats.failed += 1
            log.exception("unexpected failure on %s", path.name)
            self.db.audit("failure", f"unexpected: {exc}"[:500], rec.id)
        finally:
            self.db.upsert(rec)
            AudioPreparer.cleanup(work_dir)

        return rec

    # ---- stages ---------------------------------------------------------
    def _transcribe_audio(self, rec: Recording, path: Path, work_dir: Path) -> None:
        normalised, duration = self.audio.normalise(path, work_dir)
        rec.duration_seconds = duration
        rec.stage = Stage.PREPARED

        # Conservative pre-routing. If ANY maximum-sensitivity profile shows a
        # keyword signal from the filename, keep the whole job local. We do not
        # have a transcript yet, so this is the only signal available.
        local_only = self._filename_suggests_sensitive(path)
        if local_only:
            log.info("filename suggests a sensitive profile; forcing local ASR")

        chunks = self.audio.chunk(normalised, work_dir, duration)
        rec.transcript = transcribe(chunks, self.cfg, self.cfg.glossary, local_only=local_only)
        rec.total_cost_usd += rec.transcript.cost_usd
        rec.stage = Stage.TRANSCRIBED

        rec.transcript.segments = diarize(normalised, rec.transcript.segments, self.cfg)
        rec.stage = Stage.DIARIZED

        rec.transcript.segments, report = apply_corrections(
            rec.transcript.segments, self.cfg.glossary
        )
        if report.total:
            self.db.audit("glossary", report.summary(), rec.id)

    def _load_text(self, rec: Recording, path: Path) -> None:
        """Accept a Plaud-exported transcript directly, skipping ASR entirely."""
        raw = path.read_text(encoding="utf-8", errors="replace")
        segments = _parse_text_transcript(raw, path.suffix.lower())
        rec.transcript = Transcript(
            segments=segments,
            asr_provider="imported",
            asr_model=path.suffix.lstrip("."),
            duration_seconds=max((s.end for s in segments), default=0.0),
        )
        rec.duration_seconds = rec.transcript.duration_seconds
        rec.transcript.segments, _ = apply_corrections(rec.transcript.segments, self.cfg.glossary)
        rec.stage = Stage.TRANSCRIBED

    def _filename_suggests_sensitive(self, path: Path) -> bool:
        stem = path.stem.replace("_", " ").replace("-", " ")
        for profile in self.cfg.routable_profiles():
            if not profile.hard_local_only:
                continue
            pre = _keyword_prescore(stem, [profile])[0]
            if pre.score > 0 or profile.id in stem.lower() or profile.short_name.lower() in stem.lower():
                return True
        return False

    def _route(self, rec: Recording) -> None:
        assert rec.transcript is not None
        # Same conservatism: if the cheap keyword pass shows any signal for a
        # locked profile, do the routing call locally too.
        pres = _keyword_prescore(rec.transcript.text, self.cfg.routable_profiles())
        risky = any(
            p.score > 0.15 and self.cfg.profile(p.profile_id).hard_local_only for p in pres
        )
        rec.routes = route(rec.transcript, self.cfg, local_only=risky)
        rec.stage = Stage.ROUTED
        self.db.audit(
            "route",
            ", ".join(f"{r.profile_id}={r.confidence:.2f}" for r in rec.routes),
            rec.id,
        )

    def _gate(self, rec: Recording) -> None:
        rec.compliance = self.gate.evaluate(rec)
        detail = "; ".join(rec.compliance.reasons)[:500]
        self.db.audit(
            "compliance",
            f"allow={rec.compliance.allow} consent={rec.compliance.consent.value} :: {detail}",
            rec.id,
        )
        for warning in rec.compliance.warnings:
            log.warning("%s: %s", rec.source_name, warning)

    def _analyse(self, rec: Recording) -> None:
        assert rec.transcript is not None
        for match in rec.routes:
            if match.profile_id not in self.cfg.profiles:
                continue
            profile = self.cfg.profile(match.profile_id)

            body = rec.transcript.labelled_text()
            redacted, counts = self.gate.redact_for_llm(body, profile)
            if counts:
                rec.compliance.redactions.update(counts)

            analysis: ProfileAnalysis = extract(rec.transcript, profile, self.cfg, redacted)
            rec.analyses.append(analysis)
            rec.total_cost_usd += analysis.cost_usd

            if rec.total_cost_usd > self.halt_at:
                raise PipelineError(
                    f"run cost ${rec.total_cost_usd:.2f} exceeded "
                    f"cost.halt_usd_per_run (${self.halt_at:.2f})"
                )

        rec.stage = Stage.ANALYZED

    # ---- persistence ----------------------------------------------------
    def _persist(self, rec: Recording) -> None:
        governing = self.cfg.profile(rec.compliance.governing_profile or "unfiled")
        encrypt = governing.encrypt_at_rest
        day = (rec.recorded_at or rec.ingested_at).strftime("%Y/%m/%d")
        stem = f"{day}/{rec.id}"

        assert rec.transcript is not None
        transcript_md = self._render_transcript(rec)
        analysis_json = rec.to_json()

        if encrypt:
            ok, why = self.vault.ready()
            if not ok:
                raise VaultError(
                    f"profile '{governing.id}' requires encryption at rest but {why}"
                )
            rec.artifact_paths["transcript"] = str(
                self.vault.write(f"{stem}.transcript.md", transcript_md, rec.id)
            )
            rec.artifact_paths["analysis"] = str(
                self.vault.write(f"{stem}.analysis.json", analysis_json, rec.id)
            )
        else:
            out = self.cfg.path("outbox") / stem
            out.parent.mkdir(parents=True, exist_ok=True)
            (out.parent / f"{rec.id}.transcript.md").write_text(transcript_md, encoding="utf-8")
            (out.parent / f"{rec.id}.analysis.json").write_text(analysis_json, encoding="utf-8")
            rec.artifact_paths["transcript"] = str(out.parent / f"{rec.id}.transcript.md")
            rec.artifact_paths["analysis"] = str(out.parent / f"{rec.id}.analysis.json")

        # The artifacts table has a foreign key onto recordings, so the parent
        # row has to exist before we can index its files. The run loop upserts
        # again at the end; this one is cheap and keeps the constraint honest.
        self.db.upsert(rec)

        now = datetime.now(timezone.utc)
        for kind, key in (("transcript", "transcript"), ("analysis", "analysis")):
            self.db.record_artifact(
                rec.id, kind, rec.artifact_paths[key], encrypt,
                self.retention.expires_at(kind, governing, now),
            )

    def _render_transcript(self, rec: Recording) -> str:
        assert rec.transcript is not None
        t = rec.transcript
        header = [
            f"# {rec.source_name}",
            "",
            f"- Recording ID: `{rec.id}`",
            f"- Recorded: {(rec.recorded_at or rec.ingested_at):%Y-%m-%d %H:%M} UTC",
            f"- Duration: {t.duration_seconds / 60:.1f} min",
            f"- ASR: {t.asr_provider} / {t.asr_model}",
            f"- Speakers: {', '.join(t.speakers)}",
            f"- Profiles: {', '.join(f'{r.profile_id} ({r.confidence:.2f})' for r in rec.routes)}",
            f"- Consent: {rec.compliance.consent.value}",
            f"- Governing profile: {rec.compliance.governing_profile} "
            f"({rec.compliance.governing_sensitivity.value})",
            "",
        ]
        if rec.compliance.consent_quote:
            header += [f"> Consent captured: {rec.compliance.consent_quote}", ""]
        header += ["---", "", "## Transcript", ""]
        return "\n".join(header) + t.labelled_text()

    def _quarantine(self, rec: Recording, path: Path) -> None:
        rec.stage = Stage.QUARANTINED
        qdir = self.cfg.path("quarantine") / rec.id
        qdir.mkdir(parents=True, exist_ok=True)
        (qdir / "WHY.md").write_text(
            "# Quarantined\n\n"
            f"- File: `{rec.source_name}`\n"
            f"- Recording ID: `{rec.id}`\n"
            f"- Profiles matched: {', '.join(rec.profile_ids)}\n\n"
            "## Reasons\n\n"
            + "\n".join(f"- {r}" for r in rec.compliance.reasons)
            + "\n\n## What to do\n\n"
            "1. Listen to the opening of the recording and confirm whether consent "
            "was actually obtained.\n"
            "2. If it was, release it: `python run.py release " + rec.id + "`\n"
            "3. If it was not, delete it. That is the correct outcome, not an "
            "inconvenience.\n",
            encoding="utf-8",
        )
        try:
            shutil.copy2(path, qdir / path.name)
        except OSError as exc:
            log.error("could not copy quarantined file: %s", exc)
        log.warning("quarantined %s -> %s", rec.source_name, qdir)
        self.db.audit("quarantine", "; ".join(rec.compliance.reasons)[:500], rec.id)

    def _archive(self, rec: Recording, path: Path) -> None:
        archive = self.cfg.path("inbox") / "_processed"
        archive.mkdir(parents=True, exist_ok=True)
        try:
            shutil.move(str(path), str(archive / path.name))
        except (OSError, shutil.Error) as exc:
            log.warning("could not archive %s: %s", path.name, exc)

    # =====================================================================
    # Batch
    # =====================================================================
    def run(self, force: bool = False, limit: int | None = None) -> RunStats:
        stats = RunStats()
        files = self.discover()
        if limit:
            files = files[:limit]

        if not files:
            log.info("inbox is empty: %s", self.cfg.path("inbox"))
            return stats

        log.info("found %d file(s) to process", len(files))
        warned = False
        for path in files:
            self.process_file(path, stats, force=force)
            if not warned and stats.cost_usd > self.warn_at:
                log.warning("run cost has passed $%.2f (warn threshold)", self.warn_at)
                warned = True
            if stats.cost_usd > self.halt_at:
                log.error("halting: run cost $%.2f exceeded $%.2f",
                          stats.cost_usd, self.halt_at)
                break

        self.db.audit("run_complete", stats.summary())
        log.info("run complete: %s", stats.summary())
        return stats

    def close(self) -> None:
        self.db.close()


# =========================================================================
# Text transcript import
# =========================================================================
def _parse_text_transcript(raw: str, suffix: str) -> list[Segment]:
    """
    Parse a Plaud-exported transcript.

    SRT gives real timestamps. Plain text does not, so we synthesise a rough
    timeline at an average speaking rate. Those timestamps are approximations
    and are labelled as such; do not quote them as evidence of when something
    was said.
    """
    import re

    segments: list[Segment] = []

    if suffix == ".srt":
        blocks = re.split(r"\n\s*\n", raw.strip())
        stamp = re.compile(
            r"(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})"
        )
        for block in blocks:
            m = stamp.search(block)
            if not m:
                continue
            g = [int(x) for x in m.groups()]
            start = g[0] * 3600 + g[1] * 60 + g[2] + g[3] / 1000.0
            end = g[4] * 3600 + g[5] * 60 + g[6] + g[7] / 1000.0
            lines = [ln for ln in block.splitlines() if not stamp.search(ln) and not ln.strip().isdigit()]
            text = " ".join(ln.strip() for ln in lines).strip()
            if text:
                speaker = "SPEAKER"
                sm = re.match(r"^([A-Za-z][\w .'-]{0,30}):\s*(.+)$", text)
                if sm:
                    speaker, text = sm.group(1).strip(), sm.group(2).strip()
                segments.append(Segment(start, end, text, speaker))
        return segments

    # Plain text / markdown. Honour "Speaker: text" and "[00:12] Speaker:" forms.
    cursor = 0.0
    WORDS_PER_SECOND = 2.6
    line_re = re.compile(
        r"^(?:\[(?P<ts>\d{1,2}:\d{2}(?::\d{2})?)\]\s*)?"
        r"(?:(?P<speaker>[A-Za-z][\w .'-]{0,30}):\s*)?(?P<text>.+)$"
    )
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = line_re.match(line)
        if not m:
            continue
        text = m.group("text").strip()
        if not text:
            continue
        if ts := m.group("ts"):
            parts = [int(p) for p in ts.split(":")]
            cursor = parts[0] * 60 + parts[1] if len(parts) == 2 else parts[0] * 3600 + parts[1] * 60 + parts[2]
        duration = max(1.0, len(text.split()) / WORDS_PER_SECOND)
        segments.append(Segment(cursor, cursor + duration, text, m.group("speaker") or "SPEAKER"))
        cursor += duration
    return segments
