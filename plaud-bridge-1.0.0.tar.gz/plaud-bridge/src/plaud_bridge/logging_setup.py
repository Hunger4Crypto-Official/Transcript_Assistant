"""
Logging.

One rule that matters: transcript content never reaches a log file. Logs hold
identifiers, hashes, counts, and durations. If you ship a log to someone for
debugging, nothing private goes with it.
"""

from __future__ import annotations

import logging
import logging.handlers
import re
from pathlib import Path

_SECRET_PATTERNS = [
    re.compile(r"(sk-[A-Za-z0-9_\-]{8,})"),
    re.compile(r"(gsk_[A-Za-z0-9_\-]{8,})"),
    re.compile(r"(hf_[A-Za-z0-9_\-]{8,})"),
    re.compile(r"(Bearer\s+[A-Za-z0-9._\-]{8,})"),
]


class RedactingFilter(logging.Filter):
    """Strips API keys and, optionally, anything marked as content."""

    def __init__(self, redact_content: bool = True):
        super().__init__()
        self.redact_content = redact_content

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        for pat in _SECRET_PATTERNS:
            msg = pat.sub("[redacted-key]", msg)
        if self.redact_content and getattr(record, "content", False):
            msg = "[content withheld from logs]"
        record.msg = msg
        record.args = ()
        return True


def setup(log_dir: Path, level: str = "INFO", redact_content: bool = True,
          rotate_mb: int = 20, backups: int = 5) -> logging.Logger:
    log_dir.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger("plaud_bridge")
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.handlers.clear()
    root.propagate = False

    fmt = logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)-28s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    redactor = RedactingFilter(redact_content)

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    console.addFilter(redactor)
    root.addHandler(console)

    fileh = logging.handlers.RotatingFileHandler(
        log_dir / "bridge.log",
        maxBytes=rotate_mb * 1024 * 1024,
        backupCount=backups,
        encoding="utf-8",
    )
    fileh.setFormatter(fmt)
    fileh.addFilter(redactor)
    root.addHandler(fileh)

    return root


def get(name: str) -> logging.Logger:
    return logging.getLogger(f"plaud_bridge.{name}")
