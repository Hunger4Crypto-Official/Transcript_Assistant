"""
Consent detection.

Scans the opening window of a transcript for an announcement that the
conversation is being recorded and that the other party agreed.

Read this carefully, because the tool cannot do this part for you:

This is a detector, not a lawyer. It tells you whether you SAID the words. It
cannot tell you whether the consent was legally sufficient in the jurisdiction
where the other party was sitting. Nevada and Florida are both in your licence
footprint and both generally require all parties to consent for telephone
communications. Texas and Arizona are generally one-party. Statutes change and
get reinterpreted.

The operational rule that makes all of this moot: announce every time, get a
verbal yes on tape, every call, every state. It costs eight seconds and removes
the entire category of risk. This detector exists to catch the times you forgot.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..logging_setup import get
from ..models import Transcript

log = get("consent")

# Phrases where the producer announces recording.
_ANNOUNCE = [
    r"\brecord(?:ing|ings|ed|s)?\s+(?:this|these|those|our|the|all|every)\b",
    r"\bi'?(?:m|\s+am)?\s+record(?:ing)?\b",
    r"\bi\s+record\b",
    r"\bthis\s+(?:call|meeting|conversation)\s+is\s+being\s+recorded\b",
    r"\bbeing\s+recorded\b",
    r"\bon\s+the\s+record\b",
    r"\b(?:do\s+you\s+mind|is\s+it\s+ok(?:ay)?|any\s+objection)\b[^.?!]{0,40}\brecord",
    r"\bmind\s+if\s+i\s+record\b",
    r"\bpermission\s+to\s+record\b",
    r"\btaking\s+(?:a\s+)?record(?:ing)?\b",
    r"\bwith\s+your\s+permission\b[^.?!]{0,40}\brecord",
]

# Phrases where the other party agrees. Deliberately narrow: a bare "yeah"
# somewhere in the first ninety seconds is not consent.
_AGREE = [
    r"\b(?:yes|yeah|yep|sure|of course|absolutely|no problem|that'?s fine|go ahead|fine by me|no objection)\b",
    r"\bi\s+consent\b",
    r"\bi\s+agree\b",
    r"\bthat'?s\s+ok(?:ay)?\b",
]

_ANNOUNCE_RE = [re.compile(p, re.IGNORECASE) for p in _ANNOUNCE]
_AGREE_RE = [re.compile(p, re.IGNORECASE) for p in _AGREE]


@dataclass
class ConsentResult:
    announced: bool = False
    agreed: bool = False
    announce_quote: str = ""
    agree_quote: str = ""
    timestamp: float | None = None
    notes: list[str] = field(default_factory=list)

    @property
    def complete(self) -> bool:
        """Announcement plus an affirmative response from someone else."""
        return self.announced and self.agreed


def detect_consent(transcript: Transcript, window_seconds: float = 90.0,
                   owner_label: str | None = None) -> ConsentResult:
    result = ConsentResult()
    window = [s for s in transcript.segments if s.start <= window_seconds]
    if not window:
        result.notes.append("transcript has no content in the consent window")
        return result

    announce_idx: int | None = None
    for idx, seg in enumerate(window):
        if any(rx.search(seg.text) for rx in _ANNOUNCE_RE):
            result.announced = True
            result.announce_quote = seg.text.strip()[:300]
            result.timestamp = seg.start
            announce_idx = idx
            break

    if announce_idx is None:
        result.notes.append("no recording announcement found in the opening window")
        return result

    announcer = window[announce_idx].speaker
    # Look only AFTER the announcement, and only at a different speaker.
    for seg in window[announce_idx + 1 : announce_idx + 9]:
        if seg.speaker == announcer:
            continue
        if any(rx.search(seg.text) for rx in _AGREE_RE):
            result.agreed = True
            result.agree_quote = seg.text.strip()[:300]
            break

    if not result.agreed:
        if len({s.speaker for s in window}) <= 1:
            result.notes.append(
                "only one speaker detected; cannot confirm the other party agreed"
            )
        else:
            result.notes.append(
                "announcement found but no affirmative response from another speaker"
            )

    return result
