from .glossary import apply_corrections, CorrectionReport

__all__ = ["apply_corrections", "CorrectionReport"]
