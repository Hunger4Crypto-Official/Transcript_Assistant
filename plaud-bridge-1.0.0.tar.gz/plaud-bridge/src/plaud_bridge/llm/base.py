"""LLM provider interface plus tolerant JSON extraction."""

from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


class LLMError(RuntimeError):
    pass


@dataclass
class LLMResponse:
    text: str = ""
    provider: str = ""
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    raw: dict[str, Any] = field(default_factory=dict)


_FENCE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


def extract_json(text: str) -> dict[str, Any]:
    """
    Pull a JSON object out of a model response.

    Models add preambles, fences, and trailing commentary no matter how firmly
    you instruct otherwise. Rather than pretending they will not, we handle it:
    try the whole string, then fenced blocks, then the outermost brace pair.
    """
    candidates: list[str] = [text.strip()]

    for match in _FENCE.finditer(text):
        candidates.append(match.group(1).strip())

    first, last = text.find("{"), text.rfind("}")
    if first != -1 and last > first:
        candidates.append(text[first : last + 1])

    for candidate in candidates:
        if not candidate:
            continue
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            continue

    raise LLMError(
        "model did not return parseable JSON. First 400 chars: " + text[:400].replace("\n", " ")
    )


class LLMProvider(ABC):
    name: str = "base"
    is_cloud: bool = True

    def __init__(self, cfg):
        self.cfg = cfg

    @abstractmethod
    def available(self) -> tuple[bool, str]:
        """Return (usable, reason). Never raises."""

    @abstractmethod
    def complete(self, system: str, user: str, max_tokens: int | None = None) -> LLMResponse:
        """Single-turn completion."""
