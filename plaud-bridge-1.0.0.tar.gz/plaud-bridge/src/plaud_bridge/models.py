"""
Core data structures.

Deliberately stdlib-only dataclasses rather than pydantic. This tool should
still run in five years on a machine where you have not touched pip since.
Validation lives in config.py where it can produce useful error messages.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


class Sensitivity(str, Enum):
    """Ordered. Higher ordinal wins when profiles collide on one recording."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    MAXIMUM = "maximum"

    @property
    def rank(self) -> int:
        return {"low": 0, "medium": 1, "high": 2, "maximum": 3}[self.value]


class Stage(str, Enum):
    INGESTED = "ingested"
    PREPARED = "prepared"
    TRANSCRIBED = "transcribed"
    DIARIZED = "diarized"
    CORRECTED = "corrected"
    ROUTED = "routed"
    ANALYZED = "analyzed"
    COMPLETE = "complete"
    QUARANTINED = "quarantined"
    FAILED = "failed"


class ConsentStatus(str, Enum):
    DETECTED = "detected"
    NOT_DETECTED = "not_detected"
    NOT_REQUIRED = "not_required"
    WAIVED = "waived"


@dataclass
class Segment:
    """One diarized, timestamped span of speech."""

    start: float
    end: float
    text: str
    speaker: str = "SPEAKER_00"
    confidence: float | None = None

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)

    def stamp(self) -> str:
        m, s = divmod(int(self.start), 60)
        h, m = divmod(m, 60)
        return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Segment":
        return cls(
            start=float(d["start"]),
            end=float(d["end"]),
            text=str(d.get("text", "")),
            speaker=str(d.get("speaker", "SPEAKER_00")),
            confidence=d.get("confidence"),
        )


@dataclass
class Transcript:
    segments: list[Segment] = field(default_factory=list)
    language: str = "en"
    asr_provider: str = ""
    asr_model: str = ""
    duration_seconds: float = 0.0
    cost_usd: float = 0.0

    @property
    def text(self) -> str:
        return "\n".join(s.text.strip() for s in self.segments if s.text.strip())

    @property
    def speakers(self) -> list[str]:
        seen: list[str] = []
        for s in self.segments:
            if s.speaker not in seen:
                seen.append(s.speaker)
        return seen

    def labelled_text(self, max_chars: int | None = None) -> str:
        """Speaker-attributed, timestamped rendering. This is what the LLM sees."""
        lines: list[str] = []
        current: str | None = None
        for seg in self.segments:
            body = seg.text.strip()
            if not body:
                continue
            if seg.speaker != current:
                lines.append(f"\n[{seg.stamp()}] {seg.speaker}:")
                current = seg.speaker
            lines.append(body)
        out = "\n".join(lines).strip()
        if max_chars and len(out) > max_chars:
            head = out[: int(max_chars * 0.7)]
            tail = out[-int(max_chars * 0.25) :]
            out = f"{head}\n\n[... {len(out) - len(head) - len(tail)} characters elided ...]\n\n{tail}"
        return out

    def window(self, seconds: float) -> str:
        """Opening window. Used by the consent detector."""
        return " ".join(s.text for s in self.segments if s.start <= seconds)

    def to_dict(self) -> dict[str, Any]:
        return {
            "segments": [s.to_dict() for s in self.segments],
            "language": self.language,
            "asr_provider": self.asr_provider,
            "asr_model": self.asr_model,
            "duration_seconds": self.duration_seconds,
            "cost_usd": self.cost_usd,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Transcript":
        return cls(
            segments=[Segment.from_dict(s) for s in d.get("segments", [])],
            language=d.get("language", "en"),
            asr_provider=d.get("asr_provider", ""),
            asr_model=d.get("asr_model", ""),
            duration_seconds=float(d.get("duration_seconds", 0.0)),
            cost_usd=float(d.get("cost_usd", 0.0)),
        )


@dataclass
class RouteMatch:
    profile_id: str
    confidence: float
    keyword_score: float = 0.0
    llm_score: float = 0.0
    evidence: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ComplianceVerdict:
    """The gate's decision. `allow` false means nothing downstream runs."""

    allow: bool = True
    consent: ConsentStatus = ConsentStatus.NOT_REQUIRED
    consent_quote: str = ""
    consent_timestamp: float | None = None
    force_local_processing: bool = False
    redactions: dict[str, int] = field(default_factory=dict)
    governing_profile: str = ""
    governing_sensitivity: Sensitivity = Sensitivity.LOW
    reasons: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["consent"] = self.consent.value
        d["governing_sensitivity"] = self.governing_sensitivity.value
        return d


@dataclass
class ProfileAnalysis:
    profile_id: str
    fields: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = ""
    llm_model: str = ""
    cost_usd: float = 0.0
    requires_human_attention: bool = False
    error: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Recording:
    """The unit of work. One source file, start to finish."""

    id: str = field(default_factory=lambda: new_id("rec"))
    source_path: str = ""
    source_name: str = ""
    content_hash: str = ""
    size_bytes: int = 0
    kind: str = "audio"  # audio | text
    recorded_at: datetime | None = None
    ingested_at: datetime = field(default_factory=utc_now)
    stage: Stage = Stage.INGESTED
    duration_seconds: float = 0.0

    transcript: Transcript | None = None
    routes: list[RouteMatch] = field(default_factory=list)
    compliance: ComplianceVerdict = field(default_factory=ComplianceVerdict)
    analyses: list[ProfileAnalysis] = field(default_factory=list)

    total_cost_usd: float = 0.0
    errors: list[str] = field(default_factory=list)
    artifact_paths: dict[str, str] = field(default_factory=dict)

    @property
    def profile_ids(self) -> list[str]:
        return [r.profile_id for r in self.routes]

    @property
    def is_encrypted(self) -> bool:
        return self.compliance.governing_sensitivity.rank >= Sensitivity.HIGH.rank

    def analysis_for(self, profile_id: str) -> ProfileAnalysis | None:
        return next((a for a in self.analyses if a.profile_id == profile_id), None)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "source_path": self.source_path,
            "source_name": self.source_name,
            "content_hash": self.content_hash,
            "size_bytes": self.size_bytes,
            "kind": self.kind,
            "recorded_at": self.recorded_at.isoformat() if self.recorded_at else None,
            "ingested_at": self.ingested_at.isoformat(),
            "stage": self.stage.value,
            "duration_seconds": self.duration_seconds,
            "transcript": self.transcript.to_dict() if self.transcript else None,
            "routes": [r.to_dict() for r in self.routes],
            "compliance": self.compliance.to_dict(),
            "analyses": [a.to_dict() for a in self.analyses],
            "total_cost_usd": self.total_cost_usd,
            "errors": self.errors,
            "artifact_paths": self.artifact_paths,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)


@dataclass
class RunStats:
    started_at: datetime = field(default_factory=utc_now)
    processed: int = 0
    skipped: int = 0
    quarantined: int = 0
    failed: int = 0
    audio_seconds: float = 0.0
    cost_usd: float = 0.0

    def summary(self) -> str:
        mins = self.audio_seconds / 60.0
        return (
            f"processed={self.processed} skipped={self.skipped} "
            f"quarantined={self.quarantined} failed={self.failed} "
            f"audio={mins:.1f}min cost=${self.cost_usd:.4f}"
        )
