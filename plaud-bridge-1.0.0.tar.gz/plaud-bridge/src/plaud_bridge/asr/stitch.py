"""
Chunk stitching.

Chunks overlap on purpose so a word cut in half at a boundary survives in one
of the two copies. The cost is duplicated speech in the overlap region, which
this module removes. The approach is deliberately simple and deterministic:
drop segments from the incoming chunk that both fall inside the overlap window
and closely resemble text we already have. No model, no randomness, no
surprises at 2am.
"""

from __future__ import annotations

import re
from difflib import SequenceMatcher

from ..models import Segment

_NORM = re.compile(r"[^a-z0-9 ]+")


def _normalise(text: str) -> str:
    return _NORM.sub("", text.lower()).strip()


def _similar(a: str, b: str) -> float:
    na, nb = _normalise(a), _normalise(b)
    if not na or not nb:
        return 0.0
    if na == nb:
        return 1.0
    return SequenceMatcher(None, na, nb).ratio()


def stitch(chunk_results: list[list[Segment]], overlaps: list[float],
           similarity_threshold: float = 0.72) -> list[Segment]:
    """
    Merge per-chunk segment lists into one timeline.

    `overlaps[i]` is how many seconds at the START of chunk i repeat the end of
    chunk i-1. Segments already shifted into absolute time by the provider.
    """
    if not chunk_results:
        return []

    merged: list[Segment] = list(chunk_results[0])

    for idx in range(1, len(chunk_results)):
        incoming = chunk_results[idx]
        overlap = overlaps[idx] if idx < len(overlaps) else 0.0
        if overlap <= 0 or not merged:
            merged.extend(incoming)
            continue

        boundary = incoming[0].start + overlap if incoming else 0.0
        # Only compare against the tail of what we already have. Comparing the
        # whole transcript would be O(n^2) and would also produce false
        # positives on genuinely repeated phrases much earlier in the meeting.
        tail = [s for s in merged if s.end >= boundary - overlap - 2.0]

        kept: list[Segment] = []
        for seg in incoming:
            if seg.start < boundary:
                if any(_similar(seg.text, prev.text) >= similarity_threshold for prev in tail):
                    continue  # duplicate from the overlap window
            kept.append(seg)
        merged.extend(kept)

    merged.sort(key=lambda s: (s.start, s.end))

    # Collapse exact adjacent repeats that survived, then drop empties.
    deduped: list[Segment] = []
    for seg in merged:
        if not seg.text.strip():
            continue
        if deduped and _normalise(deduped[-1].text) == _normalise(seg.text) \
                and abs(deduped[-1].start - seg.start) < 1.5:
            deduped[-1].end = max(deduped[-1].end, seg.end)
            continue
        deduped.append(seg)

    return deduped
