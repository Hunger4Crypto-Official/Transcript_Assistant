"""
End to end spine test.

Feeds a text transcript through the whole pipeline with a stubbed LLM, then
renders a digest. Text input skips ASR, which keeps the test hermetic while
still exercising ingest, correction, routing, the compliance gate, extraction,
encrypted persistence, and digest rendering.
"""

import json
import os
import shutil
from pathlib import Path

import pytest
import yaml

from plaud_bridge.config import Config
from plaud_bridge.digest import DigestBuilder, DigestOptions
from plaud_bridge.llm.base import LLMResponse
from plaud_bridge.models import Stage
from plaud_bridge.pipeline import Pipeline

ROOT = Path(__file__).resolve().parents[1]

CLIENT_CALL = """\
Sasson: Hey Marcus, before we get started I record these calls for my notes. Is that okay with you?
Marcus: Yeah that's fine, no problem at all.
Sasson: Appreciate it. So walk me through what you've got in place right now.
Marcus: I've got a term policy through work, about two hundred thousand I think. That's it.
Sasson: And your wife, does she have anything separate?
Marcus: No, nothing. That's honestly why I called. We just had our second kid.
Sasson: Congratulations. So the concern is if something happened to you, she's covering the mortgage alone.
Marcus: Right. And the mortgage is about four hundred thousand still.
Sasson: Okay. The other thing worth looking at is disability. Your income is the asset here, not the house.
Marcus: I hadn't thought about that. What does that run?
Sasson: Depends on the elimination. Period and the own occupation definition. I'd need to quote it properly.
Marcus: The price is my worry honestly. Money's tight with the new baby.
Sasson: That's fair, and I'd rather right-size it than oversell you. Let me put two options together.
Marcus: Okay, send them over and I'll look with my wife this weekend.
Sasson: I'll have them to you by Thursday. Can you get me your date of birth and current income before then?
Marcus: Yeah I'll email you tonight.
"""

FAMILY_DINNER = """\
Sasson: How was practice today buddy?
Kid: Coach said I'm starting on Saturday!
Sasson: That's awesome. What time is the game?
Kid: Ten in the morning. And I need the permission slip signed for the field trip.
Sasson: I'll sign it tonight. Remind me at bedtime.
Kid: Also can we get pizza after the game? You said we could.
Sasson: I did say that. Pizza after the game, deal.
"""


class _StubLLM:
    """Deterministic stand-in. Returns plausible shapes for router and extractor."""

    def __init__(self):
        self.calls = []

    def __call__(self, cfg, system, user, local_only=False, max_tokens=None):
        self.calls.append({"local_only": local_only, "system": system[:80]})

        if '"scores"' in user:
            work = any(k in user.lower() for k in ("elimination period", "term policy", "disability"))
            scores = [
                {"profile_id": "insurance_agent", "score": 0.92 if work else 0.02,
                 "evidence": ["client fact find"]},
                {"profile_id": "sales_trainer", "score": 0.1, "evidence": []},
                {"profile_id": "father", "score": 0.05 if work else 0.93,
                 "evidence": ["talking with his son"]},
                {"profile_id": "husband", "score": 0.02, "evidence": []},
            ]
            return {"scores": scores}, LLMResponse(provider="stub", model="stub")

        if "meeting_type" in system or "meeting_type" in user:
            payload = {
                "meeting_type": "fact_find",
                "participants": ["Sasson", "Marcus"],
                "stated_needs": [{"timestamp": "00:21", "speaker": "Marcus",
                                  "text": "We just had our second kid."}],
                "financial_disclosures": [{"timestamp": "00:27", "speaker": "Marcus",
                                           "text": "the mortgage is about four hundred thousand"}],
                "health_disclosures": [],
                "objections": [{"type": "price", "quote": "The price is my worry honestly."}],
                "commitments_by_client": [{"timestamp": "00:48", "speaker": "Marcus",
                                           "text": "I'll email you tonight."}],
                "commitments_by_producer": [{"timestamp": "00:45", "speaker": "Sasson",
                                             "text": "I'll have them to you by Thursday."}],
                "statements_needing_review": [],
                "open_questions": ["What disability benefit amount fits the budget?"],
                "next_action": "Send two quote options by Thursday",
            }
        else:
            payload = {
                "requires_human_attention": False,
                "worth_remembering": [{"timestamp": "00:03", "speaker": "Kid",
                                       "text": "Coach said I'm starting on Saturday!"}],
                "promises_i_made": [{"what": "sign the permission slip", "when": "tonight"},
                                    {"what": "pizza after the game", "when": "Saturday"}],
                "logistics": [{"what": "game", "when": "Saturday 10:00 AM"}],
                "asks_from_them": [{"timestamp": "00:12", "speaker": "Kid",
                                    "text": "can we get pizza after the game?"}],
                "milestones": ["First time starting"],
                "next_action": "Sign the permission slip tonight",
            }
        return payload, LLMResponse(provider="stub", model="stub")


@pytest.fixture
def sandbox(tmp_path, monkeypatch):
    cfg_dir = tmp_path / "config"
    shutil.copytree(ROOT / "config", cfg_dir)

    data = yaml.safe_load((cfg_dir / "pipeline.yaml").read_text())
    for key in ("inbox", "work", "outbox", "vault", "quarantine", "logs"):
        data["paths"][key] = str(tmp_path / "data" / key)
    data["paths"]["database"] = str(tmp_path / "data" / "bridge.db")
    data["diarization"]["enabled"] = False
    (cfg_dir / "pipeline.yaml").write_text(yaml.safe_dump(data))

    monkeypatch.setenv("PLAUD_BRIDGE_PASSPHRASE", "a-long-enough-test-passphrase")

    stub = _StubLLM()
    for module in ("plaud_bridge.profiles.router", "plaud_bridge.profiles.extractor"):
        monkeypatch.setattr(f"{module}.complete_json", stub)

    cfg = Config.load(cfg_dir, root=tmp_path)
    cfg.ensure_dirs()
    return cfg, stub


def _drop(cfg, name, body):
    path = cfg.path("inbox") / name
    path.write_text(body, encoding="utf-8")
    return path


def test_client_call_routes_analyses_and_encrypts(sandbox):
    cfg, stub = sandbox
    _drop(cfg, "client-marcus.txt", CLIENT_CALL)

    pipe = Pipeline(cfg)
    try:
        stats = pipe.run()
        assert stats.processed == 1, f"expected 1 processed, got {stats.summary()}"

        rows = pipe.db.query(profile_id="insurance_agent")
        assert len(rows) == 1
        payload = json.loads(rows[0]["payload_json"])

        assert payload["stage"] == Stage.COMPLETE.value
        assert payload["compliance"]["consent"] == "detected"
        assert payload["compliance"]["governing_profile"] == "insurance_agent"

        analysis = payload["analyses"][0]
        assert analysis["fields"]["next_action"].startswith("Send two quote")
        assert analysis["fields"]["objections"][0]["type"] == "price"

        # insurance_agent is encrypt_at_rest, so artifacts must be .enc
        for path in payload["artifact_paths"].values():
            assert path.endswith(".enc"), f"{path} was written in plaintext"
            assert Path(path).exists()

        # and must decrypt back to readable content
        from plaud_bridge.storage import Vault

        text = Vault(cfg.path("vault")).read_text(
            Path(payload["artifact_paths"]["transcript"]), payload["id"]
        )
        assert "Marcus" in text
        # glossary correction survived into the stored transcript
        assert "elimination period" in text
    finally:
        pipe.close()


def test_family_recording_never_touches_a_cloud_provider(sandbox):
    cfg, stub = sandbox
    _drop(cfg, "dinner-with-kid.txt", FAMILY_DINNER)

    pipe = Pipeline(cfg)
    try:
        stats = pipe.run()
        assert stats.processed == 1

        rows = pipe.db.query(profile_id="father")
        assert len(rows) == 1

        # Every LLM call made for this recording had to be local-only.
        assert stub.calls, "no LLM calls recorded"
        assert all(c["local_only"] for c in stub.calls), (
            "a family recording reached a call that permitted cloud providers: "
            f"{[c for c in stub.calls if not c['local_only']]}"
        )

        payload = json.loads(rows[0]["payload_json"])
        assert payload["compliance"]["force_local_processing"] is True
        assert payload["compliance"]["governing_profile"] == "father"
        for path in payload["artifact_paths"].values():
            assert path.endswith(".enc")
    finally:
        pipe.close()


def test_missing_consent_quarantines(sandbox):
    cfg, stub = sandbox
    no_consent = CLIENT_CALL.split("\n", 2)[2]  # strip the consent exchange
    _drop(cfg, "client-no-consent.txt", no_consent)

    pipe = Pipeline(cfg)
    try:
        stats = pipe.run()
        assert stats.quarantined == 1
        assert stats.processed == 0

        qdirs = list(cfg.path("quarantine").iterdir())
        assert len(qdirs) == 1
        why = (qdirs[0] / "WHY.md").read_text()
        assert "consent" in why.lower()
        assert "run.py release" in why
    finally:
        pipe.close()


def test_dedupe_skips_identical_file(sandbox):
    cfg, _ = sandbox
    _drop(cfg, "client-marcus.txt", CLIENT_CALL)
    pipe = Pipeline(cfg)
    try:
        assert pipe.run().processed == 1
        _drop(cfg, "client-marcus-copy.txt", CLIENT_CALL)
        stats = pipe.run()
        assert stats.skipped == 1 and stats.processed == 0
    finally:
        pipe.close()


def test_digest_excludes_personal_by_default_and_suppresses_sensitive_fields(sandbox):
    cfg, _ = sandbox
    _drop(cfg, "client-marcus.txt", CLIENT_CALL)
    _drop(cfg, "dinner-with-kid.txt", FAMILY_DINNER)

    pipe = Pipeline(cfg)
    try:
        pipe.run()
        builder = DigestBuilder(cfg, pipe.db)

        combined = builder.render_markdown(DigestOptions(days=30))
        assert "Production" in combined
        assert "Family" not in combined, "family content leaked into the combined digest"
        # suppressed fields must not print their contents
        assert "four hundred thousand" not in combined
        assert "withheld from this view" in combined
        assert "Send two quote options by Thursday" in combined

        with_personal = builder.render_markdown(DigestOptions(days=30, include_personal=True))
        assert "Family" in with_personal
        assert "permission slip" in with_personal

        only_dad = builder.render_markdown(DigestOptions(profile_id="father", days=30))
        assert "Family" in only_dad
        assert "Production" not in only_dad
    finally:
        pipe.close()


def test_digest_surfaces_next_actions_at_the_top(sandbox):
    cfg, _ = sandbox
    _drop(cfg, "client-marcus.txt", CLIENT_CALL)
    pipe = Pipeline(cfg)
    try:
        pipe.run()
        md = DigestBuilder(cfg, pipe.db).render_markdown(DigestOptions(days=30))
        needs = md.split("## At a Glance")[0]
        assert "Needs You" in needs
        assert "Send two quote options by Thursday" in needs
    finally:
        pipe.close()
